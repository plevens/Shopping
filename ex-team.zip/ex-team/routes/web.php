<?php

use App\Http\Controllers\AmiController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::view('/', 'welcome');

Route::view('dashboard', 'dashboard')
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::view('profile', 'profile')
    ->middleware(['auth'])
    ->name('profile');
Route::view('/publication/commerce','commerce')->middleware(['auth','verified'])
->name('commerce');
Route::view('/Notification','notification')
->middleware(['auth','verified'])->name('notification');
Route::view('/Baskets','basket')
->middleware(['auth','verified'])->name('basket');

Route::view('/Cardboard','cardboard')
->middleware(['auth','verified'])->name('card');

Route::view('/forgot/passwword','password')
->middleware(['guest'])
->name('password');


require __DIR__.'/auth.php';
