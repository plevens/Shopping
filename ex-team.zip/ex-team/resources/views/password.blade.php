<x-guest-layout>
    <livewire:page.password />
</x-guest-layout>
