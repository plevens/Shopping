<d?php

use App\Livewire\Page\Accueil;
use Livewire\Volt\Component;

new class extends Component
{
    public Accueil $home;
}
?>
<div wire:poll.5000ms>
    <style>
        #styck{
            background-color:black;
            color:white;
            text-align: center;
            border:1px solid white;
        }
        tr,#aj{
            border:1px solid black;
            height: 10px
        }
        #btn{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;

        }
        label{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;
        }
        #btn:active{
            background-color:cadetblue;
            border-color:red;
        }
        #more{
            background-color: initial;
            color:blue;
            text-decoration: underline;
            cursor:pointer;
        }


    </style>
    <br>
    <br>
    <table class="sm:hidden bg-gray-800 text-white" style="font-size: 90%;"cellpadding="5">
    <thead id="styck">
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Pseudo
            </div>
            </td>

            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Name of pack
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Picture
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Description
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Number
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Price of one
            </div>
            </td>
        </thead>

        @foreach ($pub as $pubs)
            <tr>
                <td>
                <div class="sm:hidden" style="font-size: 90%;">
                    {{$pubs->pseudo}}
                    </div>
                </td>
                <td>
                <div class="sm:hidden" style="font-size: 90%;">
                    {{$pubs->nom}}
                </div>
                </td>
                <td class="image">
                  <img src="{{asset('storage/'.$pubs->photo)}}" class="hidden sm:flex"  style="width:5cm;height:5cm" alt="" srcset="">
                  <img src="{{asset('storage/'.$pubs->photo)}}" class="sm:hidden"  style="width:2cm;height:2cm" alt="" srcset="">

                </td>
                <td>
                    <div class=" sm:hidden" style="font-size: 90%;">
                       {!! $pubs->description  !!}
                    </div>

                </td>
                <td>
                    @if(!empty($pub) && $_pub == $pubs->id)
                    <input type="number" name="" wire:model="nombre" class="text-gray-800" value="{{$pubs->nombre}}" placeholder="{{$pubs->nombre}}" id="">
                    <x-primary-button wire:click="submi">
                        Update
                    </x-primary-button>
                    <x-danger-button wire:click="cancels">
                            Cancel
                     </x-danger-button>
                    @else
                    {{$pubs->nombre}}
                    @endif
                </td>
                <td>
                    {{$pubs->prix}} Ar
                </td>
            </tr>
            <tr>
                <td>
                    @if($pubs->pseudo == Auth::user()->pseudo)
                    <input type="radio" name="" wire:model="_pub" style="display:none" id="m_{{$pubs->id}}" value="{{$pubs->id}}">
                    <label for="m_{{$pubs->id}}">
                        Update
                    </label>
                    @endif
                </td>
                <td>

                </td>
                <td>

                @if ($pubs->nombre > 0 && $pubs->pseudo != Auth::user()->pseudo)

                    <input type="radio" name="" wire:model="n_achete" style="display:none" id="n_{{$pubs->id}}" value="{{$pubs->id}}">
                    @if (!empty($n_achete) && $n_achete == $pubs->id)
                    <br>
                        <input type="number" class="text-gray-800" name="number" wire:model="number" placeholder="Number" id="input_{{$pubs->id}}">
                        <br>
                        <center>
                       <x-primary-button wire:click="submit">
                        Valid
                       </x-primary-button>
                       <x-danger-button wire:click="cancels">
                            Cancel
                        </x-danger-button>
                       </center>
                    @else
                     <label for="n_{{$pubs->id}}" id="btn">
                        Baskets
                    </label>
                    @endif
                @elseif($pubs->pseudo == Auth::user()->pseudo)

                @else
                Spent
                @endif
                </td>
                <td>
                    @if (session('message') && session('id') == $pubs->id)
                        {{session('message')}}
                    @endif
                </td>
            </tr>
        @endforeach
    </table>
    <center>
    <table  class="hidden sm:flex"  align="center"   cellpadding="10">
        <tr id="styck">
        <td>
            <div  style="font-size: 90%;">
                Pseudo
            </div>
            </td>

            <td>
            <div  style="font-size: 90%;">
                Name of pack
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Picture
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Description
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Number
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Price of one
            </div>
            </td>
        </tr>

        @foreach ($pub as $pubs)
            <tr style="overflow:scroll;height:2cm;">
                <td id="aj">
                <div style="font-size: 100%;">

                <br>
                {!! substr_replace(strtoupper($pubs->pseudo),'',1).substr_replace(strtoupper(strrev($pubs->pseudo)),'',1) !!}
                    </div>
                </td>
                <td id="aj">
                <div  style="font-size: 100%;">

                {!! substr_replace($pubs->nom,"...",10)  !!}
                </div>
                </td>
                <td class="image">

                    <br>
                    <a href="{{asset('storage/'.$pubs->photo)}}">
                  <img src="{{asset('storage/'.$pubs->photo)}}" class="hidden sm:flex"  style="width:5cm;height:5cm" alt="" srcset="">
                  <img src="{{asset('storage/'.$pubs->photo)}}" class="sm:hidden"  style="width:2cm;height:2cm" alt="" srcset="">
                  </a>
                </td>
                <td id="aj" style="text-align: center;">




                    <div  style="font-size: 100%;">

                       @if ($more == $pubs->id)
                       {!! $pubs->description  !!}
                       <label for="_more_{{$pubs->id}}" id="more">See less</label>
                       <input type="radio" name="more" wire:input="seen" style="display:none;"  id="_more_{{$pubs->id}}">
                       @else
                        {!! substr_replace($pubs->description," ...",10)  !!}
                       <label for="more_{{$pubs->id}}" id="more">See more</label>
                       <input type="radio" name="more" wire:model="more" wire:input="seel" style="display:none;" value="{{$pubs->id}}" id="more_{{$pubs->id}}">
                       @endif
                    </div>

                </td>
                <td>
                    @if(!empty($pub) && $_pub == $pubs->id)
                    <input type="number" name="" wire:model="nombre" value="{{$pubs->nombre}}" placeholder="{{$pubs->nombre}}" id="">
                   <br>
                    <x-primary-button wire:click="submi">
                        Update
                    </x-primary-button>
                    <x-danger-button wire:click="cancels">
                            Cancel
                        </x-danger-button>
                    @else
                    {{$pubs->nombre}}
                    @endif
                </td>
                <td>
                    {{$pubs->prix}} Ar
                </td>
            </tr>
            <tr>
                <td>
                    @if($pubs->pseudo == Auth::user()->pseudo)
                    <input type="radio" name="" wire:model="_pub" style="display:none" id="m_{{$pubs->id}}" value="{{$pubs->id}}">
                    <br>
                    <label for="m_{{$pubs->id}}">
                        Update
                    </label>

                    @endif
                </td>
                <td>

                </td>
                <td>

                @if ($pubs->nombre > 0 && $pubs->pseudo != Auth::user()->pseudo)

                    <input type="radio" name="" wire:model="n_achete" style="display:none" id="n_{{$pubs->id}}" value="{{$pubs->id}}">
                    @if (!empty($n_achete) && $n_achete == $pubs->id)
                    <br>
                        <input type="number" name="number" wire:model="number" placeholder="Number that you'll pic" id="input_{{$pubs->id}}">
                        <br>
                        <center>
                       <x-primary-button wire:click="submit">
                        Valid
                       </x-primary-button>
                        <x-danger-button wire:click="cancels">
                            Cancel
                        </x-danger-button>
                       </center>
                    @else
                     <label for="n_{{$pubs->id}}" id="btn">
                        Baskets
                    </label>
                    @endif
                @elseif($pubs->pseudo == Auth::user()->pseudo)

                @else
                Spent
                @endif
                </td>
                <td>
                    @if (session('message') && session('id') == $pubs->id)
                        {{session('message')}}
                    @endif
                </td>
            </tr>
        @endforeach
    </table>
    </center>
