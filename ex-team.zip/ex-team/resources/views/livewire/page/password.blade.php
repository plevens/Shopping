<?php

use App\Livewire\Page\Password;
use Livewire\Attributes\Layout;
use Livewire\Volt\Component;

new #[Layout('layouts.guest')] class extends Component
{
    public Password $lost;
}

?>


<div>
    <div>
        <a href="{{route('login')}}" class="bg-gray-800 text-white rounded-md p-2 fixed" wire:navigate>Retour</a>

        <h1 class="font-5" align="center"> Forgot password</h1>
        <br>
        <div>

                <label for="email" align="left"> Your email</label>
                <input type="email" name="email"  wire:model="email" placeholder="Your email" id="email" class="w-full rounded-md">
                @if ($i == 1)
                : {{$email}}
               <b >&check;</b>
               <style>
                    #email{
                        display: contents;
                    }
               </style>
               @elseif($i == 0)
               <b style="color:red;margin-left:-0.5cm"> x </b>
            @endif
                <x-input-error :messages="$errors->get('email')" class="mt-2" />


                <br>
                <label for="">Your pseudo</label>
                <input type="text" name="pseudo" wire:model="pseudo" placeholder="Your pseudo" id="pseudo" class="w-full rounded-md">
                @if ($n == 1)
               : {{$pseudo}}
               <b >&check;</b>
               <style>
                    #pseudo{
                        display: contents;
                    }
               </style>
               @elseif($n == 0)
               <b style="color:red;margin-left:-0.5cm"> x </b>

            @endif
                <x-input-error :messages="$errors->get('pseudo')" class="mt-2" />

                <br>
                <br>
                @if ($n == 1 && $i == 1)
                @if($f == 0)
                <label for="">New password</label>
                    <input type="password" name="password" wire:model="password" placeholder="Your new Password" class="w-full rounded-md" id="">
                    <x-input-error :messages="$errors->get('password')" class="mt-2" />

                    <br>
                    <label for="">Confirm your password</label>
                    <input type="password" name="password" wire:model="password_confirmation" placeholder="Confirm your password" class="w-full rounded-md" id="">
                    <br>
                    <br>
                    <x-primary-button wire:click="update">
                        Update
                    </x-primary-button>
                @else
                    You can log in with your new password now , thank you!
                @endif
                @else
                 <x-primary-button wire:click="verifie">
                    given
                </x-primary-button>
                @endif


        </div>
    </div>
</div>
