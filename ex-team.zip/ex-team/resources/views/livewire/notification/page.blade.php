<?php

use App\Livewire\Notification\Page;
use Livewire\Volt\Component;

new class extends Component
{
    public Page $notif;
}
?>
<div wire:poll.5000ms>
    <style>
         label{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;
            cursor:pointer;
        }
    </style>
    <div class="fixed bg-gray-800 text-white p-6 text-center w-2 bottom-9">
          When the pack is done(you have delivered the pack to the person),  Clic the "Assimilation"
    </div>
    <br>
    <br>
    <br>
    <br>
        @foreach ($basket as $com)
            @foreach ($users as $user)
            @if ($com->status == "baskets")
                @if ($com->id_auth == $user->id && $com->numero == Auth::user()->numero)
                    <b style="text-transform: capitalize;">{{$user->name}}</b> will owning  <u>{{$com->nombre}} digits {{strtoupper($com->nom)}}</u> , pris: {{$com->prix}} Ar . Contact : {{$user->numero}}
                    <br>
                    <br>

                    <input type="radio" name="pubs" wire:model="pubs" wire:input="accepte" value="{{$com->id}}" id="pub_{{$com->id}}" style="display:none;">
                     <label for="pub_{{$com->id}}" >
                        Assimilation
                    </label>
                    <br>
                    <br>
                @endif
                @endif
            @endforeach
        @endforeach
</div>
