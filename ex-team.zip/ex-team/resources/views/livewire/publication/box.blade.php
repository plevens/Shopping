<?php

use App\Livewire\Publication\Box;
use Livewire\Volt\Component;

new class extends Component
{
    public Box $pub;
}
?>

<div>
    <center>
<div align="center" style="border: 1px solid black;border-width:0.1cm;box-shadow:0px 3px 5px black;width:10cm">
    @if (session('message'))
        <div class="bg-gray-800 text-white p-6">
            {{session('message')}}
        </div>
        <style>
            input[type="text"],textarea,input[type="number"], label{
                    border-color: red;
            }
        </style>
    @endif
    <form wire:submit="add">
        <br>
        <label for="image" >
@if ($photo)
<img src="{{$photo->temporaryUrl()}}" style="width: 2cm;height:2cm;" alt="">
@else
<div style="background-color: aqua;padding:10px 10px;border:1px solid black">
 Clic here to add the picture of your pack
</div>

@endif


        </label>
        <br>
        <input type="file" name="photo" wire:model="photo" accept="image/*"style="display: none;" id="image">
        <br>
        <label for="name">Name of your pack</label>
        <br>
        <input type="text" name="name" wire:model="name" placeholder="Name of your pack" id="name">
        <br>
        <label for="number">Number of your pack</label>
        <br>
        <input type="number" name="nombre" wire:model="nombre" oninput="resets()" placeholder="Number of your pack" id="number">
        <br>
<label for="prix">Price of your pack</label>
<br>
One : <input type="number" wire:model="prix" name="prix" id="prix" oninput="calcul()" placeholder="prise of your pack (Ar)" > <br>
<b id="calcul"></b>
        <br>
        <label for="description">Description of your pack</label>
        <br>
        <textarea name="decription" wire:model="description" placeholder="Description of your pack" id="description" cols="30" rows="2" style="resize: none;"></textarea>
        <br>
      <x-primary-button>
        Forwarded
      </x-primary-button>
      <br>
      <br>
    </form>
</div>
</center>
<script>
    var n = document.getElementById('prix');
    var m = document.getElementById('calcul');
    var f =document.getElementById('number');
   function calcul(params) {
    if(f.value != ""){
        m.innerText ="All : "+ n.value * f.value + 'Ar';
    }

   }
   function resets()
   {
    m.innerText = "";
    n.value = "";
   }
</script>
</div>
