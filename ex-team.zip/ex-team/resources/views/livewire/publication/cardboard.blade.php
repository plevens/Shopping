<?php

use App\Livewire\Publication\Cardboard;
use Livewire\Volt\Component;

new class extends Component
{
    public Cardboard $notif;
}
?>
<div wire:poll.5000ms>
    <style>
         label{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;
            cursor:pointer;
        }
    </style>
        @foreach ($basket as $com)
            @foreach ($users as $user)
            @if ($com->status == "Thanks")
                @if ($com->id_auth == $user->id && $com->numero == Auth::user()->numero)
                    <b style="text-transform: capitalize;">{{$user->name}}</b> owning your commerce publication <u>{{strtoupper($com->nom)}}</u> ,{{$com->nombre}} digits who spend {{$com->prix}} Ar
                        <br>
                        Storie {{$com->updated_at->diffForHumans()}}
                    <br>
                    <br>
                @endif
                @endif
            @endforeach
        @endforeach
</div>
