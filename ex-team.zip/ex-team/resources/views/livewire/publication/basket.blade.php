<?php

use App\Livewire\Publication\Basket;
use Livewire\Volt\Component;

new class extends Component
{
    public Basket $pub;
}
?>
<div wire:poll.5000ms>
<style>
        #styck{
            background-color:black;
            color:white;
            text-align: center;
            border:1px solid white;
        }
        tr{
            border:1px solid black;
        }
        #btn{
            background-color:red;
            color:white;
            padding:8px 8px;
            border-radius:5px;
            cursor:pointer;

        }
        #btn:active{
            background-color:cadetblue;
            border-color:red;
        }
    </style>
    <table style="border:1px solid black;"  align="center"  cellpadding="15" >
        @php
            $n = 0;
        @endphp
        <tr>
            <td>
                Number
            </td>
            <td>
                Name
            </td>
            <td>
                Number phone
            </td>
            <td>
                How much ?
            </td>
            <td>

            </td>
        </tr>
        @foreach ($basket as $com)
        @php
            $n++;
        @endphp
            <tr>
                <td>
                    {{$com->nombre}}
                </td>
                <td>
                    {{$com->nom}}
                </td>
                <td>
                   {{$com->numero}}
                </td>
                <td>
                    {{$com->prix}} ar
                </td>

            </tr>
            <tr>

                <td>
                <input type="radio" name="" wire:model="cancel" style="display: none;"  id="n_{{$com->id}}" value="{{$com->id_pub}}">
                @if($com->status == "baskets")

                @else
                Thank you!
                @endif
                </td>
                <td>
                    @if (!empty($cancel) && $cancel == $com->id_pub)
                        <input type="number" wire:model="nombre" name="nombre" placeholder="Number of pack cancel" id="">
                    @endif

                </td>
                <td>
                @if (!empty($cancel) && $cancel == $com->id_pub)
                    <x-danger-button wire:click="ups">
                        Valid
                    </x-danger-button>
                @endif
                </td>
                <td>
                    @if ($nombre > $com->nombre)
                        <style>
                            input[type="number"]{
                                border-color:red;
                            }
                        </style>
                        Your number is not accepted.
                    @endif
                </td>
            </tr>
        @endforeach
        @if ($n == 0)
        <tr>
            <td>
                ...
            </td>
            <td>
                ...
            </td>
            <td>
                ...
            </td>
            <td>
                ...
            </td>
        </tr>
        @endif
    </table>
</div>
