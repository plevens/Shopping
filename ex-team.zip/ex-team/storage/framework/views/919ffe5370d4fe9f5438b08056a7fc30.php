<b style="font-size:300%;">
&smashp;
</b>
<?php /**PATH C:\laragon\www\ex-team\resources\views/components/application-logo.blade.php ENDPATH**/ ?>