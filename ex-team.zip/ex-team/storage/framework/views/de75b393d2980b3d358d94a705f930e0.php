<?php

use App\Livewire\Page\Ami;
use Livewire\Volt\Component;

new class extends Component
{
    public Ami $ist;
}
?>
<div wire:poll.5000ms>
    <!--[if BLOCK]><![endif]--><?php if(session('msg')): ?>
    <?php echo e(session('msg')); ?>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!--[if BLOCK]><![endif]--><?php if($users->id != Auth::user()->id): ?>
    <div wire:key="<?php echo e($users->id); ?>">

        <?php
        $n = 0;
        $i = 0;
        $e = 0;
        ?>

        <table  wire:key="_<?php echo e($users->id); ?>">
            <tr>
                <td>
                  Photo de profil
                </td>
                <td>
                <?php echo e($users->name); ?>

                </td>
            </tr>

            <tr>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ami; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if($amis->id_auth == Auth::user()->id && $amis->id_request == $users->id && $amis->request_type == 'waiting' ): ?>
                <?php
                $i++;
                ?>
                <?php elseif($amis->id_auth == $users->id && $amis->id_request == Auth::user()->id && $amis->request_type == 'waiting' ): ?>
                <?php
                    $n++;
                ?>
                 <?php elseif($amis->id_auth == $users->id && $amis->id_request == Auth::user()->id && $amis->request_type == 'Ami' ||  $amis->id_auth == Auth::user()->id && $amis->id_request == $users->id && $amis->request_type == 'Ami'): ?>
                <?php
                    $e++;
                ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                <td>
                    <!--[if BLOCK]><![endif]--><?php if($i == 0 && $n == 0 && $e == 0): ?>
                    <input type="radio" wire:input="send" name="person" wire:model="person" value="<?php echo e($users->id); ?>" style="display: none;" id="personn_<?php echo e($users->id); ?>">
                    <label for="personn_<?php echo e($users->id); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                        Add
                    </label>
                    <?php elseif($i == 1): ?>
                    <input type="radio" wire:input="chide" name="person" wire:model="person" value="<?php echo e($users->id); ?>" style="display: none;" id="person_<?php echo e($users->id); ?>">
                    <label for="person_<?php echo e($users->id); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                        Cancel
                    </label>
                    <?php elseif($n == 1): ?>

                    <input type="radio" wire:input="accepte" name="person" wire:model="person" value="<?php echo e($users->id); ?>" style="display: none;" id="people_<?php echo e($users->id); ?>">
                        <label for="people_<?php echo e($users->id); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                            confirm
                        </label>
                        <input type="radio" wire:input="chide" name="person" wire:model="person" value="<?php echo e($users->id); ?>" style="display: none;" id="person">
                    <label for="person" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                        Cancel
                    </label>
                    <?php elseif($e==1): ?>
                      (Friend)
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => 'seen']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'seen']); ?>
                        Profil
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                </td>
            </tr>
        </table>

        <br>
</div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/page/ami.blade.php ENDPATH**/ ?>