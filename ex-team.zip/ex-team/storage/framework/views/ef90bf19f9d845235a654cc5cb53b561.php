<?php

use App\Livewire\Page\Message;
use Livewire\Volt\Component;

new class extends Component
{
    public Message $mess;
}
?>
<div>
   <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ami; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <!--[if BLOCK]><![endif]--><?php if($users->id == $amis->id_request && $amis->id_auth == Auth::user()->id && $amis->request_type == 'Ami' ||$amis->id_request == Auth::user()->id && $amis->id_auth == $users->id && $amis->request_type == 'Ami'): ?>
   <a href="<?php echo e(route('chat',['id'=>$users->id])); ?>" wire:navigate>
    <?php echo e($users->name); ?>

   </a>
   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/page/message.blade.php ENDPATH**/ ?>