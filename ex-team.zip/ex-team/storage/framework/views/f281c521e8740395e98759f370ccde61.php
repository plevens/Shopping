<?php

use App\Livewire\Publication\Box;
use Livewire\Volt\Component;

new class extends Component
{
    public Box $pub;
}
?>

<div>
    <center>
<div align="center" style="border: 1px solid black;border-width:0.1cm;box-shadow:0px 3px 5px black;width:10cm">
    <!--[if BLOCK]><![endif]--><?php if(session('message')): ?>
        <div class="bg-gray-800 text-white p-6">
            <?php echo e(session('message')); ?>

        </div>
        <style>
            input[type="text"],textarea,input[type="number"], label{
                    border-color: red;
            }
        </style>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <form wire:submit="add">
        <br>
        <label for="image" >
<!--[if BLOCK]><![endif]--><?php if($photo): ?>
<img src="<?php echo e($photo->temporaryUrl()); ?>" style="width: 2cm;height:2cm;" alt="">
<?php else: ?>
<div style="background-color: aqua;padding:10px 10px;border:1px solid black">
 Clic here to add the picture of your pack
</div>

<?php endif; ?><!--[if ENDBLOCK]><![endif]-->


        </label>
        <br>
        <input type="file" name="photo" wire:model="photo" accept="image/*"style="display: none;" id="image">
        <br>
        <label for="name">Name of your pack</label>
        <br>
        <input type="text" name="name" wire:model="name" placeholder="Name of your pack" id="name">
        <br>
        <label for="number">Number of your pack</label>
        <br>
        <input type="number" name="nombre" wire:model="nombre" oninput="resets()" placeholder="Number of your pack" id="number">
        <br>
<label for="prix">Price of your pack</label>
<br>
One : <input type="number" wire:model="prix" name="prix" id="prix" oninput="calcul()" placeholder="prise of your pack (Ar)" > <br>
<b id="calcul"></b>
        <br>
        <label for="description">Description of your pack</label>
        <br>
        <textarea name="decription" wire:model="description" placeholder="Description of your pack" id="description" cols="30" rows="2" style="resize: none;"></textarea>
        <br>
      <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        Forwarded
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
      <br>
      <br>
    </form>
</div>
</center>
<script>
    var n = document.getElementById('prix');
    var m = document.getElementById('calcul');
    var f =document.getElementById('number');
   function calcul(params) {
    if(f.value != ""){
        m.innerText ="All : "+ n.value * f.value + 'Ar';
    }

   }
   function resets()
   {
    m.innerText = "";
    n.value = "";
   }
</script>
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/publication/box.blade.php ENDPATH**/ ?>