<?php

use App\Livewire\Publication\Cardboard;
use Livewire\Volt\Component;

new class extends Component
{
    public Cardboard $notif;
}
?>
<div wire:poll.5000ms>
    <style>
         label{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;
            cursor:pointer;
        }
    </style>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $basket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php if($com->status == "Thanks"): ?>
                <!--[if BLOCK]><![endif]--><?php if($com->id_auth == $user->id && $com->numero == Auth::user()->numero): ?>
                    <b style="text-transform: capitalize;"><?php echo e($user->name); ?></b> owning your commerce publication <u><?php echo e(strtoupper($com->nom)); ?></u> ,<?php echo e($com->nombre); ?> digits who spend <?php echo e($com->prix); ?> Ar
                        <br>
                        Storie <?php echo e($com->updated_at->diffForHumans()); ?>

                    <br>
                    <br>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/publication/cardboard.blade.php ENDPATH**/ ?>