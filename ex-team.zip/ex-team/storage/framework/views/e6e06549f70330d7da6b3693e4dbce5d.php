<d?php

use App\Livewire\Page\Accueil;
use Livewire\Volt\Component;

new class extends Component
{
    public Accueil $home;
}
?>
<div wire:poll.5000ms>
    <style>
        #styck{
            background-color:black;
            color:white;
            text-align: center;
            border:1px solid white;
        }
        tr,#aj{
            border:1px solid black;
            height: 10px
        }
        #btn{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;

        }
        label{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;
        }
        #btn:active{
            background-color:cadetblue;
            border-color:red;
        }
        #more{
            background-color: initial;
            color:blue;
            text-decoration: underline;
            cursor:pointer;
        }


    </style>
    <br>
    <br>
    <table class="sm:hidden bg-gray-800 text-white" style="font-size: 90%;"cellpadding="5">
    <thead id="styck">
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Pseudo
            </div>
            </td>

            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Name of pack
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Picture
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Description
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Number
            </div>
            </td>
            <td>
            <div class="sm:hidden" style="font-size: 90%;">
                Price of one
            </div>
            </td>
        </thead>

        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                <div class="sm:hidden" style="font-size: 90%;">
                    <?php echo e($pubs->pseudo); ?>

                    </div>
                </td>
                <td>
                <div class="sm:hidden" style="font-size: 90%;">
                    <?php echo e($pubs->nom); ?>

                </div>
                </td>
                <td class="image">
                  <img src="<?php echo e(asset('storage/'.$pubs->photo)); ?>" class="hidden sm:flex"  style="width:5cm;height:5cm" alt="" srcset="">
                  <img src="<?php echo e(asset('storage/'.$pubs->photo)); ?>" class="sm:hidden"  style="width:2cm;height:2cm" alt="" srcset="">

                </td>
                <td>
                    <div class=" sm:hidden" style="font-size: 90%;">
                       <?php echo $pubs->description; ?>

                    </div>

                </td>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if(!empty($pub) && $_pub == $pubs->id): ?>
                    <input type="number" name="" wire:model="nombre" class="text-gray-800" value="<?php echo e($pubs->nombre); ?>" placeholder="<?php echo e($pubs->nombre); ?>" id="">
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'submi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submi']); ?>
                        Update
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'cancels']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'cancels']); ?>
                            Cancel
                      <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                    <?php else: ?>
                    <?php echo e($pubs->nombre); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>
                    <?php echo e($pubs->prix); ?> Ar
                </td>
            </tr>
            <tr>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if($pubs->pseudo == Auth::user()->pseudo): ?>
                    <input type="radio" name="" wire:model="_pub" style="display:none" id="m_<?php echo e($pubs->id); ?>" value="<?php echo e($pubs->id); ?>">
                    <label for="m_<?php echo e($pubs->id); ?>">
                        Update
                    </label>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>

                </td>
                <td>

                <!--[if BLOCK]><![endif]--><?php if($pubs->nombre > 0 && $pubs->pseudo != Auth::user()->pseudo): ?>

                    <input type="radio" name="" wire:model="n_achete" style="display:none" id="n_<?php echo e($pubs->id); ?>" value="<?php echo e($pubs->id); ?>">
                    <!--[if BLOCK]><![endif]--><?php if(!empty($n_achete) && $n_achete == $pubs->id): ?>
                    <br>
                        <input type="number" class="text-gray-800" name="number" wire:model="number" placeholder="Number" id="input_<?php echo e($pubs->id); ?>">
                        <br>
                        <center>
                       <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submit']); ?>
                        Valid
                        <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                       <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'cancels']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'cancels']); ?>
                            Cancel
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                       </center>
                    <?php else: ?>
                     <label for="n_<?php echo e($pubs->id); ?>" id="btn">
                        Baskets
                    </label>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php elseif($pubs->pseudo == Auth::user()->pseudo): ?>

                <?php else: ?>
                Spent
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if(session('message') && session('id') == $pubs->id): ?>
                        <?php echo e(session('message')); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </table>
    <center>
    <table  class="hidden sm:flex"  align="center"   cellpadding="10">
        <tr id="styck">
        <td>
            <div  style="font-size: 90%;">
                Pseudo
            </div>
            </td>

            <td>
            <div  style="font-size: 90%;">
                Name of pack
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Picture
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Description
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Number
            </div>
            </td>
            <td>
            <div  style="font-size: 90%;">
                Price of one
            </div>
            </td>
        </tr>

        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="overflow:scroll;height:2cm;">
                <td id="aj">
                <div style="font-size: 100%;">

                <br>
                <?php echo substr_replace(strtoupper($pubs->pseudo),'',1).substr_replace(strtoupper(strrev($pubs->pseudo)),'',1); ?>

                    </div>
                </td>
                <td id="aj">
                <div  style="font-size: 100%;">

                <?php echo substr_replace($pubs->nom,"...",10); ?>

                </div>
                </td>
                <td class="image">

                    <br>
                    <a href="<?php echo e(asset('storage/'.$pubs->photo)); ?>">
                  <img src="<?php echo e(asset('storage/'.$pubs->photo)); ?>" class="hidden sm:flex"  style="width:5cm;height:5cm" alt="" srcset="">
                  <img src="<?php echo e(asset('storage/'.$pubs->photo)); ?>" class="sm:hidden"  style="width:2cm;height:2cm" alt="" srcset="">
                  </a>
                </td>
                <td id="aj" style="text-align: center;">




                    <div  style="font-size: 100%;">

                       <!--[if BLOCK]><![endif]--><?php if($more == $pubs->id): ?>
                       <?php echo $pubs->description; ?>

                       <label for="_more_<?php echo e($pubs->id); ?>" id="more">See less</label>
                       <input type="radio" name="more" wire:input="seen" style="display:none;"  id="_more_<?php echo e($pubs->id); ?>">
                       <?php else: ?>
                        <?php echo substr_replace($pubs->description," ...",10); ?>

                       <label for="more_<?php echo e($pubs->id); ?>" id="more">See more</label>
                       <input type="radio" name="more" wire:model="more" wire:input="seel" style="display:none;" value="<?php echo e($pubs->id); ?>" id="more_<?php echo e($pubs->id); ?>">
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                </td>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if(!empty($pub) && $_pub == $pubs->id): ?>
                    <input type="number" name="" wire:model="nombre" value="<?php echo e($pubs->nombre); ?>" placeholder="<?php echo e($pubs->nombre); ?>" id="">
                   <br>
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'submi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submi']); ?>
                        Update
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'cancels']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'cancels']); ?>
                            Cancel
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                    <?php else: ?>
                    <?php echo e($pubs->nombre); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>
                    <?php echo e($pubs->prix); ?> Ar
                </td>
            </tr>
            <tr>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if($pubs->pseudo == Auth::user()->pseudo): ?>
                    <input type="radio" name="" wire:model="_pub" style="display:none" id="m_<?php echo e($pubs->id); ?>" value="<?php echo e($pubs->id); ?>">
                    <br>
                    <label for="m_<?php echo e($pubs->id); ?>">
                        Update
                    </label>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>

                </td>
                <td>

                <!--[if BLOCK]><![endif]--><?php if($pubs->nombre > 0 && $pubs->pseudo != Auth::user()->pseudo): ?>

                    <input type="radio" name="" wire:model="n_achete" style="display:none" id="n_<?php echo e($pubs->id); ?>" value="<?php echo e($pubs->id); ?>">
                    <!--[if BLOCK]><![endif]--><?php if(!empty($n_achete) && $n_achete == $pubs->id): ?>
                    <br>
                        <input type="number" name="number" wire:model="number" placeholder="Number that you'll pic" id="input_<?php echo e($pubs->id); ?>">
                        <br>
                        <center>
                       <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submit']); ?>
                        Valid
                        <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'cancels']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'cancels']); ?>
                            Cancel
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                       </center>
                    <?php else: ?>
                     <label for="n_<?php echo e($pubs->id); ?>" id="btn">
                        Baskets
                    </label>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php elseif($pubs->pseudo == Auth::user()->pseudo): ?>

                <?php else: ?>
                Spent
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if(session('message') && session('id') == $pubs->id): ?>
                        <?php echo e(session('message')); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </table>
    </center>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/page/accueil.blade.php ENDPATH**/ ?>