<?php

use App\Livewire\Page\Msg;
use Livewire\Volt\Component;

new class extends Component
{
    public Msg $mess;
}

?>

<div wire:poll.5000ms>
<input type="radio" wire:key="1" name="person" class="person" wire:model="person" id="_persons">
salut
<?php echo e($i); ?>

</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/page/msg.blade.php ENDPATH**/ ?>