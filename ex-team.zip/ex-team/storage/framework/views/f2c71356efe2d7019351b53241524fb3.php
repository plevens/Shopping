<?php

use App\Livewire\Page\Messages;
use Livewire\Volt\Component;

new class extends Component
{
    public Messages $mess;
}
?>
<div align="center">
    <!--[if BLOCK]><![endif]--><?php if(session('msg')): ?>
    <?php echo e(session('msg')); ?>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="py-12 bg-dark ">

        <input type="radio" style="display: none;" wire:model="persons" wire:key="2" wire:input="send" name="persons" checked autocomplete id="person">
        <textarea name="" id="" wire:model="message" cols="50" style="resize: none;" class="rounded-md" rows="2" placeholder="Your message"></textarea>
        <br>
        <label for="person" class="rounded-md bg-gray-500 py-1 px-3" style="cursor:pointer">
            Send
        </label>
        <input type="file" name="file" wire:model="file" accept="image/*" id="">
    </div>
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/page/messages.blade.php ENDPATH**/ ?>