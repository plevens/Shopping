<?php

use App\Livewire\Publication\Basket;
use Livewire\Volt\Component;

new class extends Component
{
    public Basket $pub;
}
?>
<div wire:poll.5000ms>
<style>
        #styck{
            background-color:black;
            color:white;
            text-align: center;
            border:1px solid white;
        }
        tr{
            border:1px solid black;
        }
        #btn{
            background-color:red;
            color:white;
            padding:8px 8px;
            border-radius:5px;
            cursor:pointer;

        }
        #btn:active{
            background-color:cadetblue;
            border-color:red;
        }
    </style>
    <table style="border:1px solid black;"  align="center"  cellpadding="15" >
        <?php
            $n = 0;
        ?>
        <tr>
            <td>
                Number
            </td>
            <td>
                Name
            </td>
            <td>
                Number phone
            </td>
            <td>
                How much ?
            </td>
            <td>

            </td>
        </tr>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $basket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $n++;
        ?>
            <tr>
                <td>
                    <?php echo e($com->nombre); ?>

                </td>
                <td>
                    <?php echo e($com->nom); ?>

                </td>
                <td>
                   <?php echo e($com->numero); ?>

                </td>
                <td>
                    <?php echo e($com->prix); ?> ar
                </td>

            </tr>
            <tr>

                <td>
                <input type="radio" name="" wire:model="cancel" style="display: none;"  id="n_<?php echo e($com->id); ?>" value="<?php echo e($com->id_pub); ?>">
                <!--[if BLOCK]><![endif]--><?php if($com->status == "baskets"): ?>

                <?php else: ?>
                Thank you!
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if(!empty($cancel) && $cancel == $com->id_pub): ?>
                        <input type="number" wire:model="nombre" name="nombre" placeholder="Number of pack cancel" id="">
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </td>
                <td>
                <!--[if BLOCK]><![endif]--><?php if(!empty($cancel) && $cancel == $com->id_pub): ?>
                    <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'ups']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'ups']); ?>
                        Valid
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <td>
                    <!--[if BLOCK]><![endif]--><?php if($nombre > $com->nombre): ?>
                        <style>
                            input[type="number"]{
                                border-color:red;
                            }
                        </style>
                        Your number is not accepted.
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($n == 0): ?>
        <tr>
            <td>
                ...
            </td>
            <td>
                ...
            </td>
            <td>
                ...
            </td>
            <td>
                ...
            </td>
        </tr>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </table>
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/publication/basket.blade.php ENDPATH**/ ?>