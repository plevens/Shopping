<?php

use App\Livewire\Notification\Page;
use Livewire\Volt\Component;

new class extends Component
{
    public Page $notif;
}
?>
<div wire:poll.5000ms>
    <style>
         label{
            background-color:blue;
            color:white;
            padding:8px 8px;
            border-radius:5px;
            cursor:pointer;
        }
    </style>
    <div class="fixed bg-gray-800 text-white p-6 text-center w-2 bottom-9">
          When the pack is done(you have delivered the pack to the person),  Clic the "Assimilation"
    </div>
    <br>
    <br>
    <br>
    <br>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $basket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php if($com->status == "baskets"): ?>
                <!--[if BLOCK]><![endif]--><?php if($com->id_auth == $user->id && $com->numero == Auth::user()->numero): ?>
                    <b style="text-transform: capitalize;"><?php echo e($user->name); ?></b> will owning  <u><?php echo e($com->nombre); ?> digits <?php echo e(strtoupper($com->nom)); ?></u> , pris: <?php echo e($com->prix); ?> Ar . Contact : <?php echo e($user->numero); ?>

                    <br>
                    <br>

                    <input type="radio" name="pubs" wire:model="pubs" wire:input="accepte" value="<?php echo e($com->id); ?>" id="pub_<?php echo e($com->id); ?>" style="display:none;">
                     <label for="pub_<?php echo e($com->id); ?>" >
                        Assimilation
                    </label>
                    <br>
                    <br>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\ex-team\resources\views/livewire/notification/page.blade.php ENDPATH**/ ?>