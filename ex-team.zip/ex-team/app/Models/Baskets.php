<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Baskets extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_pub',
        'nombre',
        'status',
        'numero',
        'prix',
        'nom',
        'id_auth',
    ];
}
