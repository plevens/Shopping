<?php

namespace App\Livewire\Page;

use App\Models\message;
use Livewire\Component;

class Msg extends Component
{

    public $person;
    public function render()
    {
        $msg = message::get();

        return view('livewire.page.msg',['msg'=>$msg]);
    }
}
