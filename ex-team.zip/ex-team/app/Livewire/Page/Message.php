<?php

namespace App\Livewire\Page;

use App\Models\Ami;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Message extends Component
{
protected $listeners = ['refreshComponent'=>'render'];
    public function render()
    {
        $user = User::all()->where('id','!=',Auth::user()->id);
        $ami = Ami::all();
        return view('livewire.page.message',['user'=>$user, 'ami'=>$ami]);
    }
}
