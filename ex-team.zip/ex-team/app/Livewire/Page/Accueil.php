<?php

namespace App\Livewire\Page;

use App\Models\Baskets;
use App\Models\Commerce;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Accueil extends Component
{
    public $n_achete;
    public $_pub;
    public $recherche = "";
    public $number;
    public $nombre;
    public $more;
    protected $listenners = ['refreshComponent'=>'render'];
    public function render()
    {
        $pub = Commerce::orderBy('created_at','desc')->get();
        return view('livewire.page.accueil',['pub'=>$pub]);
    }
    public function achete()
    {
        $this->n_achete;
    }
    public function submit()
    {
        $get = Commerce::get()->where('id',$this->n_achete);
        $nombre = 0;
        $pseudo = "";
        $prix = 0;
        $nom = "";
        foreach($get as $gets)
        {
           $nombre =  $gets->nombre;
           $pseudo = $gets->pseudo;
           $prix = $gets->prix;
           $nom = $gets->nom;
        }

        $user = User::get()->where('pseudo',$pseudo);
        foreach($user as $users)
        {
            $numero = $users->numero;
        }
        if($nombre < $this->number)
        {
            session()->flash('message','The number that you have enter is more than the pack number, please try again.');
            session()->flash('id',$this->n_achete);
        }else{
          Commerce::where('id',$this->n_achete)->update([
            'nombre'=>$nombre - $this->number,
        ]);
        $vu = Baskets::get()->where('id_auth',Auth::user()->id);
        $i = 0;
        $f = 0;
        $p = 0;
        foreach($vu as $vue)
        {
            if($vue->id_pub === $this->n_achete)
            {
                if($vue->status === 'baskets'){
                $i++;
                $p = $vue->prix;
                $f = $vue->nombre;
                }
            }
        }
if($i == 0){

        Baskets::create([
        'id_pub'=>$this->n_achete,
        'nombre'=>$this->number,
        'status'=>'baskets',
        'numero'=>$numero,
        'prix'=>$prix*$this->number,
        'nom'=>$nom,
        'id_auth'=>Auth::user()->id
        ]);
}else{
    Baskets::where('id_auth',Auth::user()->id)->where('id_pub',$this->n_achete)->where('status','baskets')->update([
        'prix'=>$p+($prix*$this->number),
        'nombre'=>$f+$this->number,
    ]);
}
        }
$this->n_achete = "";
$this->number = "";
    }
    public function submi(){

        if($this->nombre <= 0)
        {
                session()->flash('message','This action is not authorized');
        }else{
            $get = Commerce::get()->where('id',$this->_pub);
            $nombre = 0;
            $pseudo = "";
            $prix = 0;
            $nom = "";
            foreach($get as $gets)
            {
               $nombre =  $gets->nombre;
               $pseudo = $gets->pseudo;
               $prix = $gets->prix;
               $nom = $gets->nom;
            }
            Commerce::where('id',$this->_pub)->update([
                'nombre'=>$nombre + $this->nombre,
            ]);
        }
        $this->nombre = "";
        $this->_pub = "";
    }
    public function cancels()
    {
        $this->nombre = "";
        $this->n_achete = "";
        $this->_pub = "";
    }
    public function seel()
    {
        $this->more;
    }
    public function seen()
    {
        $this->more = "";
    }
}
