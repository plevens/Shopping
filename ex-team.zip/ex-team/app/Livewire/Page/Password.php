<?php

namespace App\Livewire\Page;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Illuminate\Validation\Rules;

class Password extends Component
{
    public $email = "";
    public $pseudo = "";
    public $f;
    public $n;
    public $i;
    public string $password= "";
    public string $password_confirmation = "";
    public function render()
    {
        return view('livewire.page.password');
    }

    public function verifie()
    {
        $user = User::get();
        $this->i = 0;
        $this->n = 0;
        foreach($user as $users)
        {
            if($users->email == $this->email )
            {
                $this->i++;
            }
            if($users->pseudo == $this->pseudo)
            {
                $this->n++;
            }
        }


    }
    public function update()
    {
        $valid = $this->validate([
            'password' => ['required', 'string', 'confirmed', Rules\Password::defaults()],
        ]);
        $valid['password'] = Hash::make($valid['password']);
        User::where('email',$this->email)->where('pseudo',$this->pseudo)->update([
            'password'=>$valid['password']
        ]);
        $this->f = 1;
    }
}
