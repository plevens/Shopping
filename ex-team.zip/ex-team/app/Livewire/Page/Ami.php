<?php

namespace App\Livewire\Page;

use App\Models\Ami as ModelsAmi;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class Ami extends Component
{
    public $user;
    public $person = "";
    public $ami;
    protected $listeners = ['refreshComponent' => 'render'];
    public function actualise()
    {
        $this->user = User::all();
        $this->ami = ModelsAmi::all();
    }

    public function render()
    {
        $this->user = User::all();
        $this->ami = ModelsAmi::all();
        return view('livewire.page.ami',['user'=>$this->user,'ami'=>$this->ami]);
    }
    public function send()
    {
        ModelsAmi::create([
        'id_auth'=>Auth::user()->id,
        'id_request'=>$this->person,
        'request_type'=>'waiting'
    ]);
    $this->redirect('/Personne',navigate:true);
    }
    public function chide()
    {
        $auth = Auth::user()->id;
        $user = $this->person;
       DB::delete('DELETE FROM `amis` WHERE `id_auth`="'.$auth.'" AND `id_request`="'.$user.'" OR `id_auth`="'.$user.'" AND `id_request`="'.$auth.'"');
       $this->person = "";
    }
    public function accepte()
    {
        ModelsAmi::where('id_auth',$this->person)->where('id_request',Auth::user()->id)->update([
            'request_type'=>'Ami'
        ]);
        User::where('id',Auth::user()->id)->update([
            'ami'=>(Auth::user()->ami +1 ),
        ]);
        $requests = User::get()->where('id',$this->person);
        foreach($requests as $_request)
        {
            $ami = $_request->ami;
        }
        User::where('id',$this->person)->update([
            'ami'=>($ami + 1)
        ]);
       $this->person = "";

    }
}
