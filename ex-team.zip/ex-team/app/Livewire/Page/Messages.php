<?php

namespace App\Livewire\Page;

use App\Models\message;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithFileUploads;

class Messages extends Component
{
    public $persons;
    public string $message = "";
    public $file;

    use WithFileUploads;

    public function render()
    {
        return view('livewire.page.messages');
    }
    public function send()

    {

        if(!empty($this->message))
        {
            if(!empty($this->file))
            {
                $this->file->store('public');
                $files = $this->file->store();
            }else{
                $files = "none";
            }
            message::create([
                'id_sender'=>Auth::user()->id,
                'id_recever'=>$this->persons,
                'message'=>$this->message,
                'photo'=>$files
            ]);
            $this->message = "";
        }else{
            session()->flash('msg','Il semble que votre boit de message est vide ...');
        }
    }
}
