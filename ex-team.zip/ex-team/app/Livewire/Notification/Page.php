<?php

namespace App\Livewire\Notification;

use App\Models\Baskets;
use App\Models\User;
use Livewire\Component;

class Page extends Component
{
    public string $pubs = "";
    protected $listenners = ['refreshComponent'=>"render"];
    public function render()
    {
        $user = User::get();
        $basket = Baskets::get();
        return view('livewire.notification.page',['users'=>$user, 'basket'=>$basket]);
    }
    public function accepte()
    {
        Baskets::where('id',$this->pubs)->update([
            'status'=>'Thanks'
        ]);
    }
}
