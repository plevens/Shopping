<?php

namespace App\Livewire\Layout;

use App\Livewire\Actions\Logout;
use App\Models\Baskets;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Navigation extends Component
{
    protected $listeners = ['refreshComponent' => 'render'];
    public function logout(Logout $logout)
    {
        $logout();

        $this->redirect('/', navigate: true);
    }
    public function render()
    {
        $basket_notif = Baskets::get()->where('numero',Auth::user()->numero);
        $n = 0;
        foreach($basket_notif as $notif)
        {
            if($notif->status == "baskets")
            {
                $n++;
            }

        }
        return view('livewire.layout.navigation',['n'=>$n]);
    }
}
