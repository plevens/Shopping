<?php

namespace App\Livewire\Publication;

use App\Models\Baskets;
use App\Models\Commerce;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Basket extends Component
{
    public $cancel;
    public string $nombre = "";
    protected $listenners = ['refreshComponent'=>'render'];

    public function ups()
    {
        $get = Commerce::get()->where('id',$this->cancel);
        $nombre = 0;
        $prix = 0;
        foreach($get as $gets)
        {
           $nombre =  $gets->nombre;
           $prix = $gets->prix;
        }

        $vu = Baskets::get()->where('id_auth',Auth::user()->id);
        $i = 0;
        $f = 0;
        $p = 0;
        foreach($vu as $vue)
        {
            if($vue->id_pub == $this->cancel)
            {
                $i++;
                $p = $vue->prix;
                $f = $vue->nombre;
            }
        }
        if($i == 1){
            if($f == $this->nombre)
            {
                Baskets::where('id_auth',Auth::user()->id)->where('id_pub',$this->cancel)->delete();
            }elseif($f < $this->nombre){

            }

            else{
             Baskets::where('id_auth',Auth::user()->id)->where('id_pub',$this->cancel)->update([
            'prix'=>$p-($prix*$this->nombre),
            'nombre'=>$f-$this->nombre
        ]);
            }

        }
        Commerce::where('id',$this->cancel)->update([
            'nombre'=>$nombre + $this->nombre,
        ]);
    }
    public function render()
    {
        $basket = Baskets::OrderBy('created_at','desc')->get()->where('id_auth',Auth::user()->id);
        return view('livewire.publication.basket',['basket'=>$basket]);
    }
}
