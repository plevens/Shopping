<?php

namespace App\Livewire\Publication;

use App\Models\Commerce;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithFileUploads;

class Box extends Component
{
    public string $name = "";
    public string $description = "";
    public $photo;
    public string $nombre = "";
    public string $prix = "";
    use WithFileUploads;
    public function add()
    {
        if(!empty($this->name && $this->description && $this->photo && $this->nombre && $this->prix) )
        {
            if($this->nombre >= 1){

            $this->photo->store('public');
            Commerce::create([
                'pseudo'=>Auth::user()->pseudo,
                'photo'=>$this->photo->store(),
                'description'=>nl2br($this->description),
                'nombre'=>$this->nombre,
                'nom'=>$this->name,
                'prix'=>$this->prix
            ]);
            $this->name = "";
            $this->description = "";
            $this->photo = "";
            $this->nombre = "";
            $this->prix = "";

            }else{
                session()->flash('message','The number of your product should be more or equal of 1, try again');
            }

        }else{
            session()->flash('message','All the input field is required , try again');
        }
        $this->redirect('/publication/commerce',navigate:true);
    }
    public function render()
    {
        return view('livewire.publication.box');
    }
}
