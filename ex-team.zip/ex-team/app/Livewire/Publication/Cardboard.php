<?php

namespace App\Livewire\Publication;

use App\Models\Baskets;
use App\Models\User;
use Livewire\Component;

class Cardboard extends Component
{
    protected $listenners = ['refreshComponent'=>"render"];
    public function render()
    {
        $user = User::get();
        $basket = Baskets::get();
        return view('livewire.publication.cardboard',['users'=>$user, 'basket'=>$basket]);
    }
}
