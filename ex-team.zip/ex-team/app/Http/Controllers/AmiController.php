<?php

namespace App\Http\Controllers;

use App\Models\Ami;
use App\Models\message;
use App\Models\User;
use Illuminate\Http\Request;

class AmiController extends Controller
{
    //
    protected $listeners = ['refreshComponent'=>'index'];

    public function index(User $id)
    {
        $msg = message::get();

        return view('messages',compact('id','msg'));
    }
}
